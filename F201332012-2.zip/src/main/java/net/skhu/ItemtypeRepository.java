package net.skhu;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemtypeRepository extends JpaRepository<Itemtype, Integer>  {

}
